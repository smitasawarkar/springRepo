package com.springrestcurdApplication.springrestcurdApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringrestcurdApplicationTests {

	@Test
	void contextLoads() {
	}

}
