package com.springrestcurdApplication.springrestcurdApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrestcurdApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestcurdApplication.class, args);
	}

}
